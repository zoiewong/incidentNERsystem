import numpy as np
import sentencepiece as spm
import re
import torch

import bert


class Predictor:
    def __init__(self):
        self.tokenizer = spm.SentencePieceProcessor("./tokenizer/wiki-ja.model")
        self.model = bert.IncidentModel()
        self.model.load_state_dict(
            torch.load("./model/incident_model.bin", map_location="cpu")
        )
        self.device = "cpu"
        self.max_len = 256
        self.length = 0
        self.text = []

    def inference(self, text):
        text = self.clean_text(text)
        tokens, attention_mask, token_type_ids = self.process_text([text])
        tensors = self.convert_to_tensor(tokens, attention_mask, token_type_ids)
        with torch.no_grad():
            out_pos, out_int, out_rel = self.model(
                input_ids=tensors["input_ids"],
                attention_mask=tensors["attention_mask"],
                token_type_ids=tensors["token_type_ids"],
            )
        out_pos = torch.argmax(out_pos, dim=-1)
        out_pos = out_pos.cpu().numpy().tolist()[0]

        out_int = torch.argmax(out_int, dim=-1)
        out_int = out_int.cpu().numpy().tolist()[0]

        out_rel = torch.argmax(out_rel, dim=-1)
        out_rel = out_rel.cpu().numpy().tolist()[0]

        out_pos, out_int, out_rel = self.mapping(out_pos, out_int, out_rel)
        return (
            self.text,
            out_pos[: self.length],
            out_int[: self.length],
            out_rel[: self.length],
        )

    def clean_text(self, text):
        URL = re.compile(
            r"(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]"
            + r"[a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\."
            + r"[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\."
            + r"[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\."
            + r"[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})"
        )
        MULTI_SPACE = re.compile(r"[\t ]+")
        MULTI_LINE = re.compile(r"\n\s+")
        LINE = re.compile(r"\n")

        text = URL.sub(" ", text)
        # replace multispaces to single
        text = MULTI_SPACE.sub(" ", text)
        text = MULTI_LINE.sub("\n", text)
        text = LINE.sub("。", text)
        # remove leading, trailing spaces
        text = text.strip()

        return text

    def process_text(self, text):
        tokenized_text = self.tokenizer.encode(text)
        self.length = len(tokenized_text[0])
        self.text = self.tokenizer.encode(text, out_type=str)[0]

        for i, tokens in enumerate(tokenized_text):
            if len(tokens) >= self.max_len:
                tokens = tokens[: self.max_len]
                tokens[-1] = 2
            else:
                tokens.append(1)
                n = self.max_len - len(tokens)
                paddings = [1] * n
                tokens.extend(paddings)

            tokenized_text[i] = tokens

        attention_mask = np.ones((len(tokenized_text), self.max_len))

        attention_mask[np.array(tokenized_text) == 1] = 0
        token_type_ids = np.zeros((len(tokenized_text), self.max_len))

        return tokenized_text, attention_mask, token_type_ids

    def convert_to_tensor(self, tokens, attention_mask, token_type_ids):
        return {
            "input_ids": torch.tensor(tokens, dtype=torch.long).to(self.device),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long).to(
                self.device
            ),
            "token_type_ids": torch.tensor(token_type_ids, dtype=torch.long).to(
                self.device
            ),
        }

    def mapping(self, out_pos, out_int, out_rel):
        map_pos = {
            0: "<pad>",
            1: "O",
            2: "B-Date",
            3: "I-Date",
            4: "B-Dosage",
            5: "I-Dosage",
            6: "B-Drug",
            7: "I-Drug",
            8: "B-Duration",
            9: "I-Duration",
            10: "B-Form_form",
            11: "I-Form_form",
            12: "B-Form_mode",
            13: "I-Form_mode",
            14: "B-Frequency",
            15: "I-Frequency",
            16: "B-Route",
            17: "I-Route",
            18: "B-Strength_amount",
            19: "I-Strength_amount",
            20: "B-Strength_concentration",
            21: "I-Strength_concentration",
            22: "B-Strength_rate",
            23: "I-Strength_rate",
            24: "B-Timing",
            25: "I-Timing",
            26: "B-Wrong_patient",
            27: "I-Wrong_patient",
        }

        map_int = {0: "<pad>", 1: "O", 2: "IA", 3: "IN", 4: "NA", 5: "NN"}

        map_rel = {0: "<pad>", 1: "O", 2: "1", 3: "2"}

        out_pos = list(map(lambda x: map_pos[x], out_pos))
        out_int = list(map(lambda x: map_int[x], out_int))
        out_rel = list(map(lambda x: map_rel[x], out_rel))

        return out_pos, out_int, out_rel
