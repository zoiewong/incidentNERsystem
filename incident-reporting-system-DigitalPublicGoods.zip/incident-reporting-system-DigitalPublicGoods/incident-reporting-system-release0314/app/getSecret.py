# Use this code snippet in your app.
# If you need more information about configurations or implementing the sample code, visit the AWS docs:
# https://aws.amazon.com/developers/getting-started/python/

from boto3.session import Session
from botocore.exceptions import ClientError
import ast
from config.globalConfig import AWS_REGION, SECRET_NAME


def get_secret():
    secret_name = SECRET_NAME
    session = Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=AWS_REGION,
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            print("The requested secret " + secret_name + " was not found")
        elif e.response["Error"]["Code"] == "InvalidRequestException":
            print("The request was invalid due to:", e)
        elif e.response["Error"]["Code"] == "InvalidParameterException":
            print("The request had invalid params:", e)
        print(e)
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        # Depending on whether the secret was a string or binary, only one of these fields will be populated
        if "SecretString" in get_secret_value_response:
            text_secret_data = ast.literal_eval(
                get_secret_value_response["SecretString"]
            )

        return text_secret_data
