import React from "react";

function Popupcontent(props: any) {
    return (
      <div>
        <a>1. Annotate the following 12 named entity categories if they are present in report: <br/></a>
            <table className="table-auto border pt-10 pb-10">
                <thead>
                  <tr>
                    <th className="text-xs text-left border text-black font-medium">Entity type</th>
                    <th className="text-xs text-left border text-black font-medium px-4 py-2">Definition</th>
                    <th className="text-xs text-left border text-black font-medium px-4 py-2">Examples</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="text-xs text-left border font-medium text-orange-800">Drug</td>
                    <td className="text-xs text-left border px-4 py-2">The intended to deliver or actual delivered drug name, or entities described as drugs.</td>
                    <td className="text-xs text-left border px-4 py-2">Arimidex tablet 1 mg were mistakenly delivered as Letrozole in the morning.
                    Antibiotics was missed during night shift.</td>
                  </tr>
                  <tr >
                    <td className="text-xs text-left border font-medium text-red-600">Form-form</td>
                    <td className="text-xs text-left border px-4 py-2">The form of a drug (e.g., tablet, subcuta- neous injection).</td>
                    <td className="text-xs border text-left px-4 py-2">Should have given Antibate lotion, but Antebate ointment was given.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-lime-500">Form-mode</td>
                    <td className="text-xs border text-left px-4 py-2">The mode is a drug mode of action that is associated with pharmacodynamic action.</td>
                    <td className="text-xs border text-left px-4 py-2">Sodium Valproate was prescribed, but Sodium Val- proate ER was dispensed.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-emerald-400">Strength-amount</td>
                    <td className="text-xs border text-left px-4 py-2">The amount is defined as medication dose or IV fluid volume.</td>
                    <td className="text-xs border text-left px-4 py-2">A doctor ordered Vancomycin 500 mg diluted in 100 ml normal saline, but the nurse used Vancomycin 500 mg diluted in 10 ml normal saline.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-blue-700">Strength-rate</td>
                    <td className="text-xs border text-left px-4 py-2">Rate typically represents one measure against another quantity or measure.</td>
                    <td className="text-xs border text-left px-4 py-2">Soldem3A 200 ml was set on pump and started at 100 ml/hr.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-violet-700">Strength-concentration</td>
                    <td className="text-xs border text-left px-4 py-2">Concentration is defined as diluted 
                    medication concentration with nominator and denominator or presented as percentage or IV fluid concentration.</td>
                    <td className="text-xs border text-left px-4 py-2">20% glucose was injected.
                    Precedex 200μg/2ml was dissolved in 48 ml of phys- iological saline.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-fuchsia-500">Route</td>
                    <td className="text-xs border text-left px-4 py-2">Route is defined as the route of drug ad- ministration to the patient, which may in- clude the infusion sites, routes and pumps.</td>
                    <td className="text-xs border text-left px-4 py-2">On April 6, Alpiny suppository 100 mg should be prescribed, but 200 mg was delivered.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-gray-500">Duration</td>
                    <td className="text-xs border text-left px-4 py-2">Duration is defined as period during which
                    a drug is administered to the patient.</td>
                    <td className="text-xs border text-left px-4 py-2">Inhaled medical products for 14 days 
                    were finished within 5 days.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-orange-500">Timing</td>
                    <td className="text-xs border text-left px-4 py-2">Timing is defined as a scheduled adminis- tration time that is predefined as time interval.</td>
                    <td className="text-xs border text-left px-4 py-2">Nurse forgot to give oxycodone to patient 
                    at 8 a.m.. After discovery, the nurse administrated oxycodone at 11 a.m..</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-yellow-400">Date</td>
                    <td className="text-xs border text-left px-4 py-2">Date is defined as a time unit including a date and time unit longer than one day.</td>
                    <td className="text-xs border text-left px-4 py-2">On April 6, Alpiny suppository 100 mg was given to the patient. Predonin should have been given tomorrow morning, but was administered at noon today.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-neutral-500">Frequency</td>
                    <td className="text-xs border text-left px-4 py-2">Frequency is defined as how many times a drug is given per unit of time.</td>
                    <td className="text-xs border text-left px-4 py-2">A doctor ordered heparin calcium 3 times/day for the prevention of deep thrombosis after myoma opera- tion. Nurse administered it 1 time/day.</td>
                  </tr>
                  <tr>
                    <td className="text-xs text-left border font-medium text-sky-400">Dosage</td>
                    <td className="text-xs border text-left px-4 py-2">Dosage is defined as the number of units (e.g., tables, bottles, ampules) given to the patient as a single dose.</td>
                    <td className="text-xs border text-left px-4 py-2">Doctor ordered 3×100 mg aspirin tablets 2 times/day, but the nurse gave 1×100 mg aspirin tablet.</td>
                  </tr>
                </tbody>
              </table>
            <a>2. Next, the entity needs to be labelled.<br/>
              • If the entity was intended to be given, but was not actually given, then we put Intended. <br/>
              • If the entity was not intended to be given, but was actually given, then we put Actual. <br/>
              • If the 'Error label' field is empty, this means that no error was detected relating to this named entity.<br/></a>
            <a>Annotation Example: <br/></a>
            <textarea className="text-primary border-2 h-16 w-4/5 bg-white border-slate-900" value="23時点滴交換時ハンプ0.8ｍｌ/ｈの流量設定を誤って10倍の8.0ｍｌ/ｈに設定した。2時間8ml/ｈで滴下し続け翌日1時の巡視で間違いに気づいた。"/>
            <table className="table-auto border text-center">
                <thead className="border-b bg-emerald-500">
                  <tr>
                    <th className="text-xs text-white font-medium px-4 py-2">Entity type</th>
                    <th className="text-xs text-white font-medium px-4 py-2">Intended</th>
                    <th className="text-xs text-white font-medium px-4 py-2">Actual</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="text-xs border font-medium text-orange-800 px-4 py-2">Drug</td>
                    <td colSpan={2} className="text-xs border text-orange-800 px-4 py-2">点滴</td>
                  </tr>
                  <tr >
                    <td className="text-xs border font-medium text-blue-700 px-4 py-2">Strength rate</td>
                    <td className="text-xs border text-blue-600 px-4 py-2">0.8ｍｌ/ｈ</td>
                    <td className="text-xs border px-4 py-2"></td>
                  </tr>
                  <tr>
                    <td className="text-xs border font-medium text-blue-700 px-4 py-2">Strength rate</td>
                    <td className="text-xs border px-4 py-2"></td>
                    <td className="text-xs border text-blue-600 px-4 py-2">80ｍｌ/ｈ</td>
                  </tr>
                </tbody>
              </table>
              <a>Incident error type: </a>
              <a className="font-medium">Wrong strength concentration</a>
      </div>
    );
  };
   
  export default Popupcontent;