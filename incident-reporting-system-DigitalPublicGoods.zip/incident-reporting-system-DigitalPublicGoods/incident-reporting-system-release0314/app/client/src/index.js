import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import axios from 'axios';

// FOR LOCAL DEV
// axios.defaults.baseURL = 'http://0.0.0.0:9090/';

axios.defaults.headers.post['Content-Type'] = 'application/json';
axios.defaults.headers.common["token"] = window.localStorage.getItem("token")
axios.defaults.withCredentials = true

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

