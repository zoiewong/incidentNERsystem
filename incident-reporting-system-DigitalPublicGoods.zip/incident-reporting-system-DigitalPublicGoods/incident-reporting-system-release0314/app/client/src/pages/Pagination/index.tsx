import React from "react";
import { Component, useEffect, useState } from "react";

function Pagination(props: any) {
    const { data, RenderComponent, pageLimit, dataLimit, pageNumber } = props
    const [currentPage, setCurrentPage] = useState(1);

    function goToNextPage() {
        setCurrentPage((page) => page + 1);
    }
  
    function goToPreviousPage() {
        setCurrentPage((page) => page - 1);
    }
  
    function changePage(event: any) {
      const pageNumber = Number(event.target.textContent);
      setCurrentPage(pageNumber);
    }

    function getPaginatedData() {
      const startIndex = currentPage * dataLimit - dataLimit;
      const endIndex = startIndex + dataLimit;
      return data.slice(startIndex, endIndex);
    }
  
    function getPaginationGroup() {
      let start = Math.floor((currentPage - 1) / pageLimit) * pageLimit;
      return new Array(pageNumber).fill(undefined).map((_, idx) => start + idx + 1);
    };
    
    return (
        <div>
    
        {/* show the pagiantion
            it consists of next and previous buttons
            along with page numbers, in our case, 5 page
            numbers at a time
        */}
        {/* <div className={css.pagination}> */}
          <div className="grid grid-cols-5"> 
            <div className="col-start-4">
              {/* previous button */}
              <button
                onClick={goToPreviousPage}
                disabled={currentPage === 1 ? true : false}
                className="mx-5"
              >
                ＜
              </button>
        
              {/* show page numbers */}
              {getPaginationGroup().map((item, index) => (
                <button
                  key={index + 1}
                  onClick={changePage}
                  // className={css.paginationItem} 
                  className={`${currentPage === index + 1 ? "border-2 border-slate-900 bg-emerald-400" : ""} rounded-full w-11 h-11 text-lg`}
                >
                  <span>{item}</span>
                </button>
              ))}
        
              {/* next button */}
              <button
                onClick={goToNextPage}
                disabled={currentPage >= pageNumber ? true : false}
                className="mx-5"
              >
                ＞
              </button>
          </div>
        </div>

        {/* show the posts, 10 posts at a time */}
        <div>
          {getPaginatedData().map((d:any, index:number) => {
            return( <div key={`case-${index + (currentPage-1) * dataLimit}`}><RenderComponent simil={d} /></div>)
          })}
        </div>
      </div>
    );
  };

  export default Pagination;
