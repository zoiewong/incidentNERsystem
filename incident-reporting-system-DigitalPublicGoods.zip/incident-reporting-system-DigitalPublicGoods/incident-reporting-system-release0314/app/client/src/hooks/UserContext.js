import { createContext } from 'react'; 

//set initial value of user to null (pre-login)
export const UserContext = createContext(null);