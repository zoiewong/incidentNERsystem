import React, { useState } from 'react';
import { Redirect } from "react-router-dom";
import { Link } from 'react-router-dom'
import Button from '@material-ui/core/Button';
import phaseDiagram from '../../assets/images/Picture1.png';
import arrow from '../../assets/images/arrow.png';


function Intro() {
  const intro = ["Welcome to the trial version of the 'AI-enabled Incident Reporting and Learning System'. This system is being developed by the 'AI for Patient Safety' team led by Dr. Zoie Wong at St. Luke's International University. ", <br />, <br />, "What's the purpose of this system?", <br />, "The aim of our team is to facilitate learning from past medical incidents and ultimately improve patient safety." , <br />,  <br />, "What can this system do?", <br />, "We have been investigating how to automatically capture information from unstructured, free-text incident reports and present it as structured data.", <br />, "Once an incident report has been 'structured', it can be analyzed automatically with advanced clinical AI, drawing from vast medical databases to provide the user with similar past incidents and relevant learning resources. ", <br />,  <br />, "How does it work?", <br />, "We use natural language processing to automatically extract named entities, i.e., the 'things' of interest, from incident reports. By extracting and analyzing the named entities, we can infer what type of incident occurred and other", <br />,"relevant details. This allows underlying reasons for medical incidents to be explored automatically on a large scale."];

  const phases = ["1) Submission of the Incident Report", <br />, "The user submits there incident report. The report is then automatically 'annotated', i.e.,", <br />, "each named entity within the report is categorized and prepared for further analysis. ", <br />, <br />, "2) Conversion of Report to a Structured Format", <br />, "In this phase, the user confirms that the incident report has been annotated correctly, and whether the", <br />,"source of the error has been correctly inferred. If not, the user can make corrections. ", <br />, <br />,  "3) Search for Relevant Learning Resources", <br />, "This phase is most important, as this is where the user is provided with learning resources tailored to", <br />, "the content of their submitted incident report. The user has the option to search for similar past", <br />, "medical incidents, or instead search for educational bulletins and advisories issued by hospitals,", <br />, "health agencies and other organizations. "];

    return (
      <div className="Intro">
        <div className="text-3xl font-regular bg-emerald-500 mx-0 mt-0 h-20 w-auto">
          <div className="text-white text-left pt-5 px-5">
            Incident report
          </div>  
        </div>
        <p className="text-xs font-regular pt-5 px-5">
          {intro}
        </p >
        <p className="text-xs font-bold pt-10 px-5 pb-5">
          The Three Phases of the Reporting Procedure:
        </p >
        <img className="object-contain h-24 w-160 pt-1 px-1" src={phaseDiagram} />
        <div className="flex">
          <div className="flex-none w20-1 h-14" >
            <p className="text-xs font-regular pt-5 px-5">
              {phases}
            </p >
          </div>
          <div className="flex-initial w-90 h-14">
            <p className="text-xs font-bold pt-5 px-32">
              Example:
            </p >
            <p className="text-xs font-regular pt-1 px-32">
              The doctor prescribed 50 ml of drug A to the patient, but the nurse administered 5 ml.
            </p >
            <p className="text-xs font-regular pt-1 px-32">
              Annotation:
            </p >
            <div className="py-2 lg:px-32">
              <table className="table-auto border text-center">
                <thead className="border-b bg-emerald-500">
                  <tr>
                    <th className="text-xs text-white font-medium px-4 py-2">Entity type</th>
                    <th className="text-xs text-white font-medium px-4 py-2">Intended</th>
                    <th className="text-xs text-white font-medium px-4 py-2">Actual</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="text-xs border font-medium text-orange-800 px-4 py-2">Drug</td>
                    <td colSpan={2} className="text-xs border text-orange-800 px-4 py-2">Drug A</td>
                  </tr>
                  <tr >
                    <td className="text-xs border font-medium text-blue-600 px-4 py-2">Strength amount</td>
                    <td className="text-xs border text-blue-600 px-4 py-2">50ml</td>
                  </tr>
                  <tr>
                    <td className="text-xs border font-medium text-blue-600 px-4 py-2">Strength amountt</td>
                    <td className="text-xs border px-4 py-2"></td>
                    <td className="text-xs border text-blue-600 px-4 py-2">5ml</td>
                  </tr>
                </tbody>
              </table>
            </div>
        </div>
        </div>
        <div>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <Link to="/login" className="btn btn-primary text-xs pt-5 pl-5 absolute bottom-9 right-32">Loginn   </Link>
          <img className="object-contain h-15 w-15 pt-5 px-5 absolute bottom-6 right-12" src={arrow} />
        </div>
      </div>
    );
  }
  
  export default Intro;