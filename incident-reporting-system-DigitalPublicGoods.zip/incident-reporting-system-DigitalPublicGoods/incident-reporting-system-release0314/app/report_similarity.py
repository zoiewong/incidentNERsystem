import os
import glob
import numpy as np
import pandas as pd
import regex as re
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
import json
from database import selectReports


class Adviser:
    def __init__(self):
        self.base_url = "https://www.med-safe.jp/pdf/"
        self.nlp = spacy.load("ja_core_news_md")
        self.report_vectorizer = TfidfVectorizer(tokenizer=self.preprocess_report)
        self.text_vectorizer = TfidfVectorizer(tokenizer=self.preprocess_text)
        self.files = "./data/med-safe_text/"
        # self.reports = './data/sample_reports/test_50.xlsx'
        # self.reports = "./data/sample_reports/522_annotated_and_labelized_entities.xlsx"
        self.reports = "./data/sample_reports/extracted_5K.xlsx"
        text_df = pd.DataFrame(columns=["file", "content"])
        for name in sorted(glob.glob(self.files + "*")):
            if "attachment" not in name:
                with open(name, "rb") as f:
                    text = f.read().decode("utf-8")
                    rows = text.split("\n")
                    no_in_string = [
                        i for i, s in enumerate(rows) if s.startswith("No.")
                    ]
                    footer = [i for i, s in enumerate(rows) if s.startswith("※")]
                    if len(no_in_string) > 2:
                        content = rows[no_in_string[1] + 1 : footer[0]]
                    else:
                        content = rows[no_in_string[0] + 1 : footer[0]]
                    cleared_content = list(
                        filter(lambda x: len(x) > 0 and "\u3000" not in x, content)
                    )
                    merged_text = "".join([r for r in cleared_content])
                    filename = os.path.basename(name).replace("txt", "pdf")
                    text_df = text_df.append(
                        pd.Series([filename, merged_text], index=text_df.columns),
                        ignore_index=True,
                    )
        self.text_df = text_df
        self.tfidf_advice = self.text_vectorizer.fit_transform(
            text_df["content"].values.tolist()
        )

        reports = pd.read_excel(self.reports, engine="openpyxl")
        reports = reports.fillna("")
        reportTypes = []
        for id_ in reports["id"].values:
            if id_[0] == "A":
                type_ = "Accident"
            else:
                type_ = "Near Miss"
            reportTypes.append(type_)
        reports["reportType"] = reportTypes
        self.reports = reports

        groups = reports.groupby(["id", "reports", "reportType"]).groups

        InputRows = []
        try:
            inputReportsDf = selectReports("All")
            inputReportsDf = inputReportsDf[inputReportsDf["reportType"].notna()]
            for row in inputReportsDf[
                ["id", "report", "corrected_entities", "reportType"]
            ].values.tolist():
                InputRows.append([row[0], row[1], json.loads(row[2].replace("'", '"')), row[3]])
        except Exception as e:
            print("-" * 10)
            print("Database table does not exist", e)
        inputReportsDf = pd.DataFrame(
            InputRows, columns=["id", "report", "corrected_entities", "reportType"]
        )

        id_report_ent = []
        for group in groups.items():
            current_id = group[0][0]
            current_report = group[0][1]
            reportType = group[0][2]
            try:
                entities = reports.iloc[list(group[1])]
                entity_list = []
                for idx, ent in entities.iterrows():
                    entity_dict = {}
                    entity_dict["entity"] = ent["entity_name"]
                    entity_dict["entityType"] = ent["entity_type"]
                    entity_dict["intention"] = ent["label"]
                    entity_dict["relationship"] = ent["index"]
                    entity_list.append(entity_dict)
                id_report_ent.append(
                    [current_id, current_report, entity_list, reportType]
                )
            except Exception as e:
                print("Get entities error", e)

        for row in inputReportsDf.values.tolist():
            entity_list = []
            for ent in row[2]:
                entity_dict = {}
                entity_dict["entity"] = ent["entity"]
                entity_dict["entityType"] = ent["entityType"]
                entity_dict["intention"] = ent["intention"]
                entity_dict["relationship"] = ent["relationship"]
                entity_list.append(entity_dict)
            id_report_ent.append([str(row[0]), row[1], entity_list, row[3]])
        self.id_report_ent = id_report_ent
        self.List1 = self.report_vectorizer.fit_transform(
            [x[1] for x in id_report_ent]
        ).toarray()

    def preprocess_report(self, text):
        clean_text = text.lower()  # converts any english word in lower case
        clean_text = re.sub(
            r"\W", "", clean_text
        )  # removing any non-words characters which include special characters, comma, punctuation
        clean_text = re.sub(r"[0-9]*年?[0-9]+月", "", clean_text)  # removing dates
        clean_text = re.sub(r"\d", "", clean_text)  # removing any digits
        clean_text = re.sub(r"[a-z]+", "", clean_text)
        clean_text = re.sub(
            r"\s+", "", clean_text
        )  # removing any extra spaces in middle
        clean_text = re.sub(
            r"^\s", "", clean_text
        )  # removing any extra spaces in beginning
        clean_text = re.sub(r"\s$", "", clean_text)  # removing any extra spaces in end

        doc = self.nlp(clean_text)

        stop_words = self.nlp.Defaults.stop_words

        return [t.text for t in doc if t not in stop_words]

    def preprocess_text(self, text):
        clean_text = text.lower()  # converts any english word in lower case
        clean_text = re.sub(
            r"\W", "", clean_text
        )  # removing any non-words characters which include special characters, comma, punctuation
        clean_text = re.sub(
            r"\s+", "", clean_text
        )  # removing any extra spaces in middle
        clean_text = re.sub(
            r"^\s", "", clean_text
        )  # removing any extra spaces in beginning
        clean_text = re.sub(r"\s$", "", clean_text)  # removing any extra spaces in end

        doc = self.nlp(clean_text)

        stop_words = self.nlp.Defaults.stop_words

        return [t.text for t in doc if t not in stop_words]

    def closest_advice(self, report):
        # Reading extracted .txt files
        simil_for_report = []
        source_list = self.tfidf_advice.toarray()
        query_list = self.text_vectorizer.transform([report])[0].toarray()[0]
        similarity_scores = source_list.dot(query_list) / (
            np.linalg.norm(source_list, axis=1) * np.linalg.norm(query_list)
        )
        simil_for_report = np.array(similarity_scores)
        max_idx = np.argmax(simil_for_report)
        closest_file = self.text_df.loc[max_idx, "file"]

        return self.base_url + closest_file

    def find_similar_cases(self, text, reportType):
        List2 = self.report_vectorizer.transform([text])[0].toarray()[0]
        similarity_scores = self.List1.dot(List2) / (
            np.linalg.norm(self.List1, axis=1) * np.linalg.norm(List2)
        )
        c = 0
        result_list = []
        for group in self.id_report_ent:
            current_id = group[0]
            current_report = group[1]
            entities = group[2]
            source_reportType = group[3]
            # cos_simil = self.cosine_sim(text, current_report, self.text_vectorizer)
            cos_simil = similarity_scores[c]
            if reportType == "All":
                result_list.append(
                    {
                        "id": current_id,
                        "reportText": current_report,
                        # "year": group[0][2].replace('年', ''),
                        "year": "2019",
                        "similarity_score": cos_simil,
                        "reportEntities": entities,
                    }
                )
            else:
                if source_reportType == reportType:
                    result_list.append(
                        {
                            "id": current_id,
                            "reportText": current_report,
                            # "year": group[0][2].replace('年', ''),
                            "year": "2019",
                            "similarity_score": cos_simil,
                            "reportEntities": entities,
                        }
                    )
            c += 1
        sorted_list = sorted(
            result_list, key=lambda item: item["similarity_score"], reverse=True
        )[:100]
        return sorted_list
