# Prepare infrastructure of incident report demo system on AWS

This is the resource picture on the aws account for the project.

![Architecture diagram](Infrastructure.jpg)

All configurations set by AWS web console
### Virtual Private Cloud
1. Create **VPC** with default configs. The created **VPC** settings should be look like this.
    ![vpc](vpc.png)
2. Create public and private **subnets**.
    - Public
        ![pubSubnet](pubSubnet.png)
    - Private
        ![privSubnet](privSubnet.png)
### Docker image registry
3. Create Private **Elastic Container Registry** repository named `incident_report` with default settings.
    ![ecr](ecr.png)
### S3 storage
4. Make sure your aws account write objects to **S3**. So that ElasticBeanstalk can upload application code to the **S3**.
### Cognito
5. Create **Cognito User Pool** with configurations down below
    1. Users and groups
        - Create test user account with username and password. Created user will look like this.
        ![cognitoUser](cognitoUsers.png)
        - Set password if Account Status is FORCE_CHANGE_PASSWORD. You can use command:
            ```shell
            admin-set-user-password
            --user-pool-id <value>
            --username <value>
            --password <value>
            --permanent
            ```
    2. Attributes
        - Only use `Username` option.
    3. Policies
        - Configure your required password strength
        - Set to `Only allow administrators to create users`
    4. MFA and verifications
        - Off
        - No verification
    5. Advanced security
        - No
    6. Message customizations
        - No - Use Cognito (Default)
    7. Tags
        - No tags
    8. Devices
        - Set No to remembering user's devices
    9. App clients
        - Create App client
        - Do not choose `Generate client secret` option
        - Enable option `Enable username password auth for admin APIs for authentication (ALLOW_ADMIN_USER_PASSWORD_AUTH)`
        - Enable `Cognito User Pool` in Enabled Identity Providers
            ![appClient](appClient.png)
    10. Triggers
        - None
    11. Analytics
        - None
### Security group
6. Create new security group and edit inbound rules
    ![inboundRule](inboundRule.png)

### ElasticBeanstalk (main service)
You can check out full exported configuration of ElasticBeanstalk environment in `incidentReportEb` file.
7. Create new Environment on EB console
- Choose `Web server environment` in Select Environment tier section
- Give application name
- Give environment a name
- Give name for EB provided domain
- On the Platform section
    - Choose `Managed Platform`
    - Choose `Docker` as the platform
    - Choose `Docker running on 64bit Amazon Linux 2` as a Platform branch
    - Choose `3.4.12` as a version
- Choose `Configure more options`
    - Choose `Custom configuration` in Presets
    - Edit `Instances` section
        - Choose `General Purpose (SSD)` in Root volume and choose size of EC2 storage
        - Choose the security group you created in Step 6
    - Edit `Capacity` section
        - Choose `Load balanced` in Environment type. And set MAX, MIN number instances in case it needs to auto-scale.
        - Choose `On-Demand Instances` in Fleet Composition section
        - Choose `x86` in Processor
        - Choose instance type (for example current system uses `t3.medium`)
    - Edit `Load balancer` section
        - Choose `Application Load Balancer` as type
        - Choose `Dedicated`
    - Edit `Security` section
        - Choose default provided `IAM instance profile`
    - Edit `Network` section
        - Choose VPC that you created in step 1
        - Load balancer subnets
            - Choose the public subnet that you created in step 2
        - Instance subnets
            - Choose the public subnet that you created in step 2
        - Database subnets
            - Choose the private subnet that you created in step 2
    - Edit `Database` section
        - Snapshot `None`
        - Engine `mysql`
        - Engine version `8.0.27`
        - Select instance class (for example `db.t2.micro`)
        - Choose storage size
        - Create username
        - Create password for the username
        - Availability (for example `Low (one AZ)`)
        - Choose `Retain` in database deletion policy
    - Other configs are default
        
### Secrets Manager
8. In AWS Secret Manager console create a secret named `incidentReportSecrets`
    - Store secrets
        | Secret key | Secret value example | Description |
        | ---------- | ---- | ---- |
        | BASIC_AUTH |  | |
        | DBhost | aa179fasdfk8oenl8jw.csfw9emx6kdu.ap-northeast-1.rds.amazonaws.com:3306 | RDS endpoint that create in EB database |
        | DBport | 3306 | port that specified in EB database |
        | DBname | ebdb | db name that specified in EB database |
        | DBusername | admin | db username that specified in EB database |
        | DBpassword | 1234 | db password that specified in EB database |
        | USERPOOLID | ap-northeast-1_lGasdfjs4yYTZ | Cognito user pool id that created in step 5 |
        | APPCLIENTID | 3ud1l5vg3gca2abasdf61djvmkmv9b | Cognito app client id that created in step 5 |

### IAM role
9. Edit IAM role that created in EB in `Identity and Access Management (IAM)` console.
Add policies down below (Add permissions --> Create Inline policy):
    - CognitoAuth
        - Action: `cognito-idp:AdminInitiateAuth`
        - Resource: Put ARN of cognito that created in step 5
    - ECRPull
        - Action: all Read and List actions
        - Resource: Put ARN of ECR that created in step 3
    - SecretsRead
        - Action: all Read and List actions
        - Resource: Put ARN of ECR that created in step 8

### Web application firewall
10. In AWS WAF console go to configure web ACL
    - Choose `Application load balancer` in Resource type to associate with
    - Select Application load balancer that you created in ElasticBeanstalk section

### Route 53 (domain setting)
11. Purchase domain and connect to the EB link
    - In route 53 web console choose Domain registration
        - Choose your domain, fill out domain owner information and purchase
    - After you successfully purchase domain, AWS will automatically create hosted zone for your domain. In hosted zone:
        - Create new record
            - Create subdomain name in record name
            - Choose `A-Routes traffic to ....` option in record type
            - Enable `Alias`
            - In choose endpoint select `Alias to Elastic Beanstalk environment` option
            - Choose EB region in region

### SSL connection for HTTPS
12. In AWS Certificate Manager console:
    - Request new certificate
    - Choose public certificate
    - Put subdomain that created in step 11
    - Choose `DNS validation` in validation
    - Click on create record after
    - After you successfully created certificate go to the EB environment Configuration
        - In load balancer config add listener
            - Choose `443` in port
            - Choose `HTTPS` in protocol
            - Choose SSL certificate that you created