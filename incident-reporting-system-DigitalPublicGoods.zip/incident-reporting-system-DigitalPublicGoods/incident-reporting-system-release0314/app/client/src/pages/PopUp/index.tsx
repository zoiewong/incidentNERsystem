import React from "react";
import css from "./style.module.css";
 
function Popup(props: any) {
  return (
    <div className={css.popupbox}>
      <div className={css.box}>
        <span className={css.closeicon} onClick={props.handleClose}>x</span>
        {props.content}
      </div>
    </div>
  );
};
 
export default Popup;