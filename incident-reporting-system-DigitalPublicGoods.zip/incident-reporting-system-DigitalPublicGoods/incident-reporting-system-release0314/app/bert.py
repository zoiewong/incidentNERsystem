import torch.nn as nn
from transformers import BertConfig, BertModel


class IncidentBert(nn.Module):
    def __init__(self, reinit_n_layers=0):
        super().__init__()
        self.config = BertConfig.from_pretrained("./model/config.json")
        self.bert = BertModel(config=self.config)

        self.dropout = nn.Dropout(0.3)
        self.fc = nn.Linear(768, 28)

        self._init_weights(self.fc)

        self.reinit_n_layers = reinit_n_layers
        if reinit_n_layers > 0:
            self._do_reinit()

    def _do_reinit(self):
        for n in range(self.reinit_n_layers):
            self.bert.encoder.layer[-(n + 1)].apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=self.bert.config.initializer_range)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)

    def forward(self, input_ids, attention_mask, token_type_ids):

        bert_out = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        output = bert_out.last_hidden_state

        output = self.dropout(output)
        output = self.fc(output)

        return output


class IncidentModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.bert = IncidentBert()
        self.fc_int = nn.Linear(28, 5)
        self.fc_rel = nn.Linear(28, 4)

    def forward(self, input_ids, attention_mask, token_type_ids):
        bert_out = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        output_int = self.fc_int(bert_out)
        output_rel = self.fc_rel(bert_out)
        return bert_out, output_int, output_rel
