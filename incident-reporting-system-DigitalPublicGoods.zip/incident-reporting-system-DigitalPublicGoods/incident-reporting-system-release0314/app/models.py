from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from database import Base


class ReportTable(Base):
    __tablename__ = "InputReports"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64))
    report = Column(String(1024))
    predicted_entities = Column(String(2048))
    corrected_entities = Column(String(2048))
    predicted_incidentTypes = Column(String(512))
    corrected_incidentTypes = Column(String(512))
    adviseUrl = Column(String(512))
    reportType = Column(String(128))
    reportedYear = Column(String(16))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
