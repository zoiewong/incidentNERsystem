from getSecret import get_secret


SECRETS = get_secret()
BASIC_AUTH = SECRETS["BASIC_AUTH"]
# BASIC_AUTH = "medIncRep:$apr1$3gnmk4qt$EVaCZaw.nASu0YBHNSCXx1"

with open("/etc/nginx/.htpasswd", "w") as f:
    f.write(BASIC_AUTH)
