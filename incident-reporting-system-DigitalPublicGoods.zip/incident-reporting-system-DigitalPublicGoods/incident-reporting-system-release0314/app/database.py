import sqlalchemy as db
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from getSecret import get_secret
from sqlalchemy.sql import text
import pandas as pd
from config.globalConfig import ENVIRONMENT, DEV_DB_HOSTNAME, DEV_DB_PORT, DEV_DB_DATABASE, DEV_DB_USERNAME, DEV_DB_PASSWORD

if ENVIRONMENT == "DEV":
    # DEVELOPMENT
    # FOR DOCKER
    # DB_HOSTNAME = "host.docker.internal"
    # FOR LOCAL
    DB_HOSTNAME = DEV_DB_HOSTNAME
    DB_PORT = DEV_DB_PORT
    DB_DATABASE = DEV_DB_DATABASE
    DB_USERNAME = DEV_DB_USERNAME
    DB_PASSWORD = DEV_DB_PASSWORD
else:
    # PRODUCTION
    SECRETS = get_secret()
    DB_HOSTNAME = SECRETS['DBhost']
    DB_PORT = SECRETS['DBport']
    DB_DATABASE = SECRETS['DBname']
    DB_USERNAME = SECRETS['DBusername']
    DB_PASSWORD = SECRETS['DBpassword']


CONN_STR = "mysql+pymysql://{0}:{1}@{2}/{3}?charset=utf8mb4".format(
    DB_USERNAME, DB_PASSWORD, DB_HOSTNAME, DB_DATABASE
)


engine = db.create_engine(CONN_STR, pool_recycle=3600)


def open_connection():
    conn = engine.connect()
    return conn


def close_connection(conn):
    conn.close()
    engine.dispose()


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def insertReports(queryDict):
    conn = open_connection()
    query_insert = text(
        """
                    INSERT INTO InputReports (username, report, predicted_entities, predicted_incidentTypes, reportType, reportedYear) VALUES (:username, :report, :predicted_entities, :predicted_incidentTypes, :reportType, :reportedYear);
                """
    )
    result = conn.execute(
        query_insert,
        username=queryDict["username"],
        report=queryDict["report"],
        predicted_entities=queryDict["predicted_entities"],
        predicted_incidentTypes=queryDict["predicted_incidentTypes"],
        reportType=queryDict["reportType"],
        reportedYear=queryDict["reportedYear"],
    )
    close_connection(conn)
    return result


def updateReports(report_text, queryDict):
    conn = open_connection()
    query_update = text(
        """
        UPDATE InputReports SET corrected_entities = :corrected_entities, corrected_incidentTypes = :corrected_incidentTypes WHERE report = :report;
    """
    )
    result = conn.execute(
        query_update,
        corrected_entities=queryDict["corrected_entities"],
        corrected_incidentTypes=queryDict["corrected_incidentTypes"],
        report=report_text,
    )
    close_connection(conn)
    return result


def selectReports(reportType):
    conn = open_connection()
    if reportType == "All":
        qry = """select * from InputReports;"""
    else:
        qry = f"""select * from InputReports where reportType = '{reportType}';"""
    qry_result = pd.read_sql(qry, conn)
    qry_result = qry_result.drop_duplicates(subset="report")
    close_connection(conn)
    return qry_result
