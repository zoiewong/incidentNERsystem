import requests
import os

url = "https://onedrive.live.com/download?cid=74086755007FD274&resid=74086755007FD274%21124&authkey=AK2FNu3JT-5q3lo"
dest = os.getcwd() + "/model/incident_model.bin"
print("Downloading Incident model...")
r = requests.get(url)
open(dest, "wb").write(r.content)
