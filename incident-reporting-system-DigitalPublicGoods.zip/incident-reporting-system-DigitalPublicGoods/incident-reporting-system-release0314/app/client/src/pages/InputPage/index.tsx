import { render } from "@testing-library/react";
import React, { Component, useEffect, useState } from "react";
import axios from 'axios';
import { EditText, EditTextarea } from 'react-edit-text';
import 'react-edit-text/dist/index.css';
import { View, Text } from 'react-native';
import SearchIcon from '../../assets/images/search.png';
import Popup from '../PopUp';
import Popupcontent from '../PopUpContent';
import SummaryPopUp from '../SummaryPopUp';
import Nurse from '../../assets/images/nurse.png';
import TrashIcon from '../../assets/images/trash.png';
import Pagination from '../Pagination';

//text colors
const color_dict: { [key: string]: string } = {
  "Drug" : "text-amber-700",
  "Strength_amount" : "text-emerald-400",
  "Dosage" : "text-sky-400",
  "Form_form" : "text-red-600",
  "Form_mode": "text-lime-500",
  "Strength_rate" : "text-blue-700",
  "Strength_concentration" : "text-violet-700",
  "Route" : "text-fuchsia-500",
  "Duration" : "text-gray-500",
  "Timing" : "text-orange-500",
  "Date" : "text-yellow-400",
  "Frequency" : "text-neutral-500"
}

const incident_options = [ 
  "Wrong Drug", 
  "Wrong Strength_amount",
  "Wrong Strength_rate",
  "Wrong Strength_concentration",
  "Wrong Dosage",
  "Wrong Form_form",
  "Wrong Form_mode",
  "Wrong Route",
  "Wrong Date",
  "Wrong Duration",
  "Wrong Timing",
  "Wrong Frequency",
  "Drug Omission",
  "Extra Drug",
  "Others"
];

interface Output {
  id : number,
  entity: string, 
  entityType: string, 
  intention: string, 
  relationship: string
};

interface SimilCase {
  id : string,
  type : string,
  year : string,
  error : string[],
  reportText : string,
  reportEntities : Output[]
};

function YesNoButtons(props: any){
  return(
    <div>
      <label>
        Is this annotation correct ?
      </label>
      <div className="flex flex-row ">
        <button onClick={props.yesClick} className="flex-initial w-20 border-x border-y text-center text-emerald-500 border-slate-900 rounded bg-zinc-200 font-medium">
          yes
        </button>
        <button onClick={props.noClick} className="flex-initial w-20 border-x border-y text-center text-red-500 border-slate-900 rounded bg-zinc-200 font-medium">
          no
        </button>
      </div>
    </div>
  );
}

function CorrectEntity(props: any){
  const [corrections, setCorrections] = useState(props.entity);

  const handleChange = (e: { target: { name: any; value: any; }; }) => setCorrections({ ...corrections, [e.target.name]: e.target.value });

  React.useEffect(() => {
    if (props.onChange) {
      props.onChange(corrections)
    }
  }, [corrections])

  return (
    <div className="pt-5">
      <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8">
        <div>
          New Entity: <input type="text" name="entity" value={corrections.entity} className="bg-zinc-200" onChange={handleChange} />
          <hr className="w-2/3"/>
        </div> 
        <div>
          <p>
            New Entity Type: <select name="entityType" value={corrections.entityType} className="text-primary" onChange={handleChange} >
              <option value=""></option>
              <option className={`${color_dict['Drug']}`} value="Drug">Drug</option>
              <option className={`${color_dict["Form_form"]}`} value="Form_form">Form_form</option>
              <option className={`${color_dict['Form_mode']}`} value="Form_mode">Form_mode</option>
              <option className={`${color_dict['Route']}`} value="Route">Route</option>
              <option className={`${color_dict['Strength_amount']}`} value="Strength_amount">Strength_amount</option>
              <option className={`${color_dict['Strength_rate']}`} value="Strength_rate">Strength_rate</option>
              <option className={`${color_dict['Strength_concentration']}`} value="Strength_concentration">Strength_concentration</option>
              <option className={`${color_dict['Dosage']}`} value="Dosage">Dosage</option>
              <option className={`${color_dict['Duration']}`} value="Duration">Duration</option>
              <option className={`${color_dict['Date']}`} value="Date">Date</option>
              <option className={`${color_dict['Timing']}`} value="Timing">Timing</option>
              <option className={`${color_dict['Frequency']}`} value="Frequency">Frequency</option>
          </select>
          </p>
          <hr className="w-3/4"/>
        </div>
        <div>
          <p>
            New Error Label: <select name="intention" value={corrections.intention} className="text-primary" onChange={handleChange} >
            <option value="Blank"></option>
            <option value="IA">IA</option>
            <option value="IN">IN</option>
            <option value="NA">NA</option>
            <option value="NN">NN</option>
          </select>
          </p>
          <hr className="w-2/5"/>
        </div>
      </dl>
    </div>
  )
}

function Entity(props: any){
  const [correct, setCorrect] = useState(true);
  const [content] = useState(props.content);
  // Used to store corrected entity
  const [correctContent, setCorrectContent] = useState(props.content);

  useEffect(() => {
    if (props.correction) {
      props.correction({index: correctContent.id, outputEntity : content, correctEntity : correctContent});
    }
  }, [content, correctContent])

  const handleYesClick = () => {
    setCorrect(true);
    console.log("yes");
    console.log(correct);
  }

  const handleNoClick = () => {
    setCorrect(false);
    console.log("no");
    console.log(correct);
  }

  const eventhandler = (data: Output) => {
    console.log(data);
    setCorrectContent(data);
  }

  let fields;
  if (correct) {      
    fields = <div></div>    
  } else {
    fields = <CorrectEntity onChange={eventhandler} entity={content}/>;
  }
  return (
    <div className="pl-10 pt-5">
      <dl className="space-y-10 grid grid-cols-3 gap-x-5">
        <div>
          <p className={`${color_dict[content.entityType]} font-medium`}>
            {content.entity}
          </p>
          <hr className="w-1/3"/>
        <YesNoButtons yesClick={handleYesClick} noClick={handleNoClick}/>
        </div> 
        <div>
          <p>
            Entity Type: <b className={`${color_dict[content.entityType]} font-medium`}>{content.entityType}</b>
          </p>
          <hr className="w-2/3"/>
        </div>
        <div>
          <p>
            Error Label: <b className="font-medium">{content.intention}</b>
          </p> 
          <hr className="w-1/4"/>
        </div>
      </dl>
        {fields}
    </div>
  )
}

function CorrectIncident(props: any){
  const [checked, setChecked] = useState(new Array(incident_options.length).fill(false));
  const [incidentValues, setIncidentValues] = useState([""])

  useEffect(() => {
    let checkedList : boolean[] = [];
    let values : string[] = [];
    incident_options.map((item) => {
      let alreadyChecked = false;
      if (props.incident.includes(item)) {
        alreadyChecked = true;
        values.push(item);
      }
      checkedList.push(alreadyChecked);
    })
    setChecked(checkedList);
    setIncidentValues(values);
  }, [props.incident])

  useEffect(() => {
    if (props.onChange) {
      props.onChange(incidentValues)
    }
  }, [incidentValues])

  const handleOnChange = (index : number) => {
    let checkList = [...checked];
    checkList[index] = !checkList[index];
    setChecked(checkList);
    let values : string[] = []
    checkList.map((v, i) => {
      if(v) {values.push(incident_options[i])} 
    })
    setIncidentValues(values);
  }

  return (
    <div>
      <dl className="w-3/3">
      <div>
        <div>
          Correct Incident Type(s):
          <hr className="w-3/3"/>
          <div className="ml-5">
            {incident_options.map((item,i) => {
              return(
                <li key={i} className="list-none">
                  <div>
                    <input
                      type="checkbox"
                      id={`checkbox-${i}`}
                      name={item}
                      value={item}
                      checked={checked[i]}
                      onChange={() => handleOnChange(i)}
                      className="w-4 h-4"
                    />
                    <label htmlFor={`checkbox-${i}`}> {item}</label>
                  </div>
                </li>
              )
            })}
          </div>
          <hr className="w-3/3"/>
        </div>
      </div> 
      </dl>
    </div>
  )
}

function Incident(props: any) {
  const [incidentTypes] = useState(props.incident)
  const [correct, setCorrect] = useState(true)
  // Used to store corrected incident
  const [correctIncident, setCorrectIncident] = useState(props.incident)

  useEffect(() => {
    if (props.correction) {
      props.correction(correctIncident);
    }
  }, [correctIncident])

  const handleYesClick = () => {
    setCorrect(true);
    console.log("yes");
    console.log(correct);
  }

  const handleNoClick = () => {
    setCorrect(false);
    console.log("no");
    console.log(correct);
  }

  const eventhandler = (data: string[]) => {
    console.log(data);
    setCorrectIncident(data);
  }

  const incidentListToString = (incidents: string[]) => {
    let incident = "";
    incidents.slice(0, incidents.length - 1).map((item : string) => {
      incident += item + ", ";
    })
    incident += incidents[incidents.length - 1];
    return incident;
  }
  
  return (
    <div className="pl-10">
      <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8">
        <div>
          <p>
            Incident Type(s) : <b>{incidentListToString(incidentTypes)}</b>
          </p>
          <hr className="w-4/5"/>
        <YesNoButtons yesClick={handleYesClick} noClick={handleNoClick}/>
        </div>
        <div>
          {!correct && 
            <CorrectIncident onChange={eventhandler} incident={incidentListToString(incidentTypes)}/>
          }
        </div>
        </dl>
      </div>
  );
}

function Explaination(){
  const [isOpen, setIsOpen] = useState(false);

  const togglePopup = () => {
    setIsOpen(!isOpen);
  }
  return(
    <div>
      <div className="flex justify-center items-center">
        <p className="flex-initial border-2 border-emerald-500 w-2/6 rounded font-medium p-2">
          Please confirm that the annotations, error labels and incident type are correct.
          If not, please make corrections using the drop-down menus provided.<br />
          For an overview of the types of named entities, and an explanation of error labels, <a href="#" onClick={togglePopup} className="text-blue-500" type="button">click here</a>.<br />
          When everything is correct, please feel free to save and register the report to our database.
        </p>
        <img className="object-contain h-28 w-44" src={Nurse} />
      </div>  
        <hr className="mt-5"/>
        {isOpen && <Popup
          content={<>
            <Popupcontent/>
          </>}
          handleClose={togglePopup}
        />}
    </div>
  );
}

function NewEntity(props: any) {
  //TODO: change relationship value (can't be added when a new entity is created)
  const [entity, setEntity] = useState({id: props.lastIndex + 1, entity: "", entityType: "", intention: "", relationship: "0" });
  const [clicked, setClicked] = useState(false);

  const eventhandler = (data: Output) => {
    console.log(data);
    setEntity(data);
  };

  const handleClick = () => {
    setClicked(true);
    props.addEntity(entity);
  };

  return (
    <div className="ml-10">
      {!clicked && 
        <div>
          <CorrectEntity onChange={eventhandler} entity={entity}/>
          <button className="flex-initial w-24 border-2 text-center border-slate-900 bg-blue-400 rounded font-medium" onClick={handleClick}>Ok</button>
        </div>
      }
    </div>
  )
}

function CaseInfo(props: any) {
  const [info] = useState(props.info.reportEntities);
  const [reportUrl] = useState("https://www.med-safe.jp/mpreport/view/" + props.info.id);

  function renderIA(i: Output) {
    if (i.intention === "IA") {
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.entityType]} text-center text-lg border-2 border-slate-900`}>{i.entityType}</div>
          <div className={`${color_dict[i.entityType]} col-span-2 text-center text-lg border-2 border-slate-900`}>{i.entity}</div>
        </div>
      )
    } else if (i.intention === "IN"){
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.entityType]} text-center text-lg border-2 border-slate-900`}>{i.entityType}</div>
          <div className={`${color_dict[i.entityType]} text-center text-lg border-2 border-slate-900`}>{i.entity}</div>
          <div className="border-2 border-slate-900"></div>
        </div>
      )
    } else if (i.intention === "NA"){
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.entityType]} text-center text-lg border-2 border-slate-900`}>{i.entityType}</div>
          <div className="border-2 border-slate-900"></div>
          <div className={`${color_dict[i.entityType]} text-center text-lg border-2 border-slate-900`}>{i.entity}</div>
        </div>
      )
    } else {
      return (null)
    }
  }
  
  return (
    <div className="flex-initial ml-5 pb-5 w-3/5">
      <p>Annotation results :</p>
      <div className="grid grid-cols-3 bg-emerald-400 border-2 border-slate-900">
        <div className="text-center border-r-4 border-slate-900">Entity type</div>
        <div className="text-center">Intended</div>
        <div className="text-center">Actual</div>
      </div>
      {info.map((item: Output) => {
          return(renderIA(item))
      })}
      <div className="mt-5">
        <a href={reportUrl} target="_blank" className="text-blue-600">View the full report</a>
      </div>
    </div>
  )
}

function SimilarCase(props: any) {
  const [closeCase] = useState(props.simil);
  const [displayClicked, setDisplayClicked] = useState(false);
  const [buttonText, setButtonText] = useState("Display");

  const handleClick = () => {
    buttonText === "Display" ? setButtonText("Hide") : setButtonText("Display");
    setDisplayClicked(!displayClicked);
  }; 

  const incidentListToString = (incidents: string[]) => {
    let incident = "";
    incidents.slice(0, incidents.length - 1).map((item : string) => {
      incident += item + ", ";
    })
    incident += incidents[incidents.length - 1];
    return incident;
}
  
  return (
    <div className="bg-zinc-200 w-4/5 mb-5">
      <div className="flex-initial ml-5 pt-5 grid grid-cols-4 gap-x-5 w-4/5">
        <p>Report type : {closeCase.type}</p>
        <p>Report ID : {closeCase.id}</p>
        <p>Reported year : {closeCase.year}</p>
        <p>Error type(s) : {incidentListToString(closeCase.error)}</p>
      </div>
      <div className="ml-5 pb-5 grid grid-cols-4 gap-x-5">
        <textarea className="flex-initial text-primary border-2 col-span-3 h-16 bg-white border-slate-900" value={closeCase.reportText} disabled/>
        <div>
          <button className="flex-initial border-x border-y h-10 w-1/3 text-center border-slate-900 rounded bg-white font-medium" onClick={handleClick}>
            {buttonText}
          </button>
        </div>
      </div>
      {displayClicked && <CaseInfo info={closeCase}/>}
    </div>
  )
}


function Input() {
  
  const [inputText, setInputText] = useState("");
  const [reportType, setReportType] = useState("Near Miss");
  const [outputText, setOutputText] = useState([{id: 0, entity: "", entityType: "", intention: "", relationship: "" }]);
  const [incidentTypes, setIncidentTypes] = useState(["Others"]);
  const [correctIncidentTypes, setCorrectIncidentTypes] = useState(["Others"]);
  const [allEntities, setAllEntities] = useState(new Array(outputText.length).fill(undefined))
  const [adviceUrl, setAdviceUrl] = useState("");
  const [text, setText] = useState("Add new entity");
  const [addEntity, setAddEntity] = useState(false);
  const [loading, setLoading] = useState(false);
  const [keywords, setKeywords] = useState("");
  const [caseType, setCaseType] = useState("All");
  const [similarCases, setSimilarCases] = useState([{id : "", type : "", year : "", error : [""], reportText : "", reportEntities : [{ entity: "", entityType: "", intention: "", relationship: "" }]}]);
  const [searching, setSearching] = useState(false);
  const [caseProcessing, setCaseProcessing] = useState(false);
  const [allData, setAllData] = useState({});
  const [summaryOpen, setSummaryOpen] = useState(false);

  async function askOutputs() {
    const response = await axios.post("/api/predict", {text: inputText, reportType: reportType})
    return response.data
  }

  async function askAdviceUrl() {
    const response = await axios.post("/api/advise", {text: inputText, reportType: reportType})
    return response.data
  }

  async function askSimilarCases() {
    const response = await axios.post("/api/similar_cases", {text: keywords, case_type: caseType})
    return response.data
  }

  async function askFinalData() {
    const response = await axios.post("/api/correct_annotation", {entities: allEntities, incidentTypes: incidentTypes, correctIncidentTypes: correctIncidentTypes, text: inputText, reportType: reportType})
    return response.data
  }

  function predict() {
    if (inputText.length > 0) {
      setSearching(false);
      setLoading(true);
      askAdviceUrl()
        .then(data => {
          console.log(data)
          setAdviceUrl(data);
        })
        .catch(err => console.log(err))
        
      const entities : Output[] = [];
      const fullEntities : any[] = [];
      askOutputs()
        .then(data => {
          console.log(data);
          setIncidentTypes(data.incidentTypes);
          data.entities.map((item : Output, index : number) => {
            entities.push({...item, id : index} );
            fullEntities.push({index : index, outputEntity : item, correctEntity : item});
          })
          setLoading(false);
        })
        .catch(err => console.log(err))
      setOutputText(entities);
      setAllEntities(fullEntities);
    } else {
      alert("The input report cannot be empty.");
    }
  }

  function search() {
    const cases: SimilCase[] = [];
    setSearching(true);
    setCaseProcessing(true);
    askSimilarCases()
      .then(data => {
        data.map((item: SimilCase) => {
          cases.push(item);
        })
        setCaseProcessing(false);
      })
      .catch(err => console.log(err))

      setSimilarCases(cases);
      console.log(searching);
  }

  function saveData() {
    console.log(outputText);
    console.log(allEntities);
    askFinalData()
      .then(data => {
        console.log("Saved")
        console.log(data);
        setAllData(data);
        toggleSummaryPopup();
      })
      .catch(err => console.log(err))
  }

  const handleClick = () => {
    text === "Add new entity" ? setText("Cancel") : setText("Add new entity");
    setAddEntity(!addEntity);
    console.log(addEntity);
  };

  const handleAdd = (data : Output) => {
    if (data.entity.length > 0 && data.entityType.length > 0 && data.intention.length > 0) {
      setOutputText([...outputText, data]);
      setAllEntities([...allEntities, {index : data.id, outputEntity : data, correctEntity: data}])
    }
    console.log(outputText);    
    console.log(allEntities);
    setText("Add new entity");
    setAddEntity(false);
  };

  const onIncidentCorrection = (correctIncident : string[]) => {
    console.log(correctIncident);
    setCorrectIncidentTypes(correctIncident);
  }

  const onEntityCorrection = (correctEntity : any) => {
    let entities = allEntities.slice();
    for (let i = 0; i < entities.length; i++) {
      if (entities[i].index === correctEntity.index) {
        entities.splice(i, 1, correctEntity);
      }
    }
    setAllEntities(entities);
  }

  const removeEntity = (idx : number) => {
    let filteredOutput = outputText.filter(function (entity) {
      return (entity.id != idx); 
    })

    let filteredEntities = allEntities.filter(function (entity) {
      return (entity.index != idx); 
    })
    setOutputText(filteredOutput);
    setAllEntities(filteredEntities); 
    console.log(outputText);
    console.log(allEntities);
  }

  const toggleSummaryPopup = () => {
    setSummaryOpen(!summaryOpen);
  }

  let addingEntity;
  if (addEntity) {      
    addingEntity = <NewEntity addEntity={handleAdd} lastIndex={outputText[outputText.length-1].id}/>;
  } else {
    addingEntity = <div></div>;
  }
  
  return (
    <div className="Input grid grid-cols-1 gap-y-5">
      <div className="text-3xl font-regular bg-emerald-500 mx-0 mt-0 h-20 w-auto">
        <div className="text-white text-left pt-5 px-5">
          Submission of Incident Report
        </div>  
      </div>
      <div className='h-16 ml-10 grid grid-cols-1'>
        <label>Please select the report type: </label>
        <select name="reportType" className="text-primary border-2 bg-zinc-200 flex-initial w-1/5 border-slate-900" onChange={(e) => {
              setReportType(e.target.value);
        }}>
          <option value="Near Miss">Near Miss</option>
          <option value="Accident">Accident</option>
        </select>
      </div>
      <div className='ml-10 grid grid-cols-1'>
        <label>Please fill in the details of the incident report : </label>
        <div className='flex h-16'>
            <input type="text" placeholder="Input text report" className="text-primary border-2 bg-zinc-200 flex-initial w-4/5 border-slate-900" onChange={(e) => {
              setInputText(e.target.value);
            }}/>
            <button onClick={predict} className="flex-initial w-24 border-2 text-center border-slate-900 bg-blue-400 rounded font-medium">
                Submit
            </button>
        </div>
        {loading && 
          <div className="flex items-center justify-center space-x-2 animate-pulse mt-10">
            <p className="font-medium text-emerald-400 text-3xl">Loading</p>
            <div className="w-10 h-10 bg-emerald-400 rounded-full"></div>
            <div className="w-10 h-10 bg-emerald-400 rounded-full"></div>
            <div className="w-10 h-10 bg-emerald-400 rounded-full"></div>
          </div>
        }
      </div>
      
      {outputText.length > 0 && adviceUrl != "" &&
        <div>
          <Explaination />
          <div className="grid grid-cols-1 gap-y-5 mt-5">
            <div className="grid grid-cols-1 gap-y-10">
              <ul id="entityList">
              {outputText.map((x)=>{
                return (
                <li key={x.id}>
                  <div className="grid grid-cols-6 items-center">
                    <div className="col-span-5"><Entity content={x} correction={onEntityCorrection} /></div>
                    {outputText.length > 1 &&
                      <div className="col-span-1">
                        <button onClick={() => removeEntity(x.id)} className="flex-initial border-2 w-14 h-14 p-2 bg-red-600 border-white-500 rounded font-medium mt-5">
                        <img src={TrashIcon} alt="Delete" />
                        </button>
                      </div>
                    }
                  </div>
                </li>
                );})}
              {outputText.filter((option) => JSON.stringify(option.intention) == 'IN'? <Text>Report type:{option.entityType}</Text>: null)}
              </ul>
              {addingEntity}
            </div>
            <button onClick={handleClick} className="flex-initial ml-10 w-32 border-x border-y text-center border-slate-900 rounded bg-zinc-200 font-medium">
                {text}
            </button>
            <Incident incident={incidentTypes} correction={onIncidentCorrection}/>
            <p className="ml-10"><a href={adviceUrl} target="_blank" className="text-blue-500 ">How to avoid similar incident in the future ?</a></p>
            {summaryOpen && <Popup
              content={
                <SummaryPopUp data={allData} report={inputText}/>
              }
              handleClose={toggleSummaryPopup}
            />}
            <hr />
            <div className="flex pl-10 mb-5">
              <button onClick={saveData} className="flex-initial w-30 border-2 text-center bg-blue-400 border-slate-900 rounded font-medium">
                <p className="m-3">Save & Register</p>
              </button>
              <div className="ml-5 w-3/5 grid grid-cols-8 gap-x-0">
                <div className="flex col-span-6">
                  <input type="text" placeholder="Search similar cases" className="text-primary w-2/3 border-2 bg-zinc-200 flex-initial border-emerald-500 rounded" onChange={(e) => {
                      setKeywords(e.target.value);
                  }}/>
                  <select name="reportType" className="text-primary border-2 bg-zinc-200 flex-initial w-1/3 border-emerald-500 rounded" onChange={(e) => {
                        setCaseType(e.target.value);
                  }}>
                    <option value="All">All</option>
                    <option value="Near Miss">Near Miss</option>
                    <option value="Accident">Accident</option>
                  </select>
                </div>
                <button onClick={search} className="flex-initial border-2 text-center w-16 bg-white border-emerald-500 rounded font-medium">
                  <img src={SearchIcon} alt="Search" />
                </button>
                {caseProcessing &&
                  <div className="flex space-x-2 col-span-1 animate-pulse pt-2">
                    <div className="w-8 h-8 bg-emerald-400 rounded-full"></div>
                    <div className="w-8 h-8 bg-emerald-400 rounded-full"></div>
                    <div className="w-8 h-8 bg-emerald-400 rounded-full"></div>
                  </div>
                }
              </div>
            </div>
            {searching &&
            <div className="ml-10 mb-5 grid-cols-1 gap-y-10">
              <p className="text-lg">Search results for similar cases : {similarCases.length}</p>
              
              {similarCases.length > 0 ? (
                  <Pagination
                    data={similarCases}
                    RenderComponent={SimilarCase}
                    pageLimit={5}
                    dataLimit={10}
                    pageNumber={Math.ceil(similarCases.length / 10)}
                  />
              ) : (
              <h1>No Posts to display</h1>
              )}
            </div>
          }
        </div>
      </div>
      }
    </div>
  );
}

export default Input;
