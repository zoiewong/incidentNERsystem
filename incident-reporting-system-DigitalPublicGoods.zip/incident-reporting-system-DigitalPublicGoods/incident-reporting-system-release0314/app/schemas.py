from typing import List, Optional
from pydantic import BaseModel


class ModelInput(BaseModel):
	text: str


class ModelOutput(BaseModel):
    text: List[str]
    out_pos: List[str]
    out_int: List[str]
    out_rel: List[str]
