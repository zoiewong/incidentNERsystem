import boto3
from config.globalConfig import AWS_REGION
from getSecret import get_secret
SECRETS = get_secret()

cognito_idp = boto3.client('cognito-idp', region_name=AWS_REGION)


def cognito_auth(user, passwd):
    try:
        cognito_result = cognito_idp.admin_initiate_auth(
            UserPoolId=SECRETS["USERPOOLID"],
            ClientId=SECRETS["APPCLIENTID"],
            AuthFlow="ADMIN_NO_SRP_AUTH",
            AuthParameters={
                "USERNAME": user,
                "PASSWORD": passwd,
            }
        )
        return cognito_result
    except Exception as e:
        print(e)
        return None


def get_current_user(access_token):
    try:
        username = cognito_idp.get_user(AccessToken=access_token)["Username"]
        return username
    except Exception as e:
        print(e)
        return None
