import React from 'react';

export default function Prompt(props){
    return(
        <h5 className="prompt">{props.prompt}</h5>
    )
}