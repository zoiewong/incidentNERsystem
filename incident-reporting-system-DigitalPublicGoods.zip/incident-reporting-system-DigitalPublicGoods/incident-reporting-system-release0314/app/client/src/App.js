import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'; 
import { UserContext } from './hooks/UserContext';
import PrivateRoute from './pages/PrivateRoute';
import Login from './pages/LoginPage/index';
import Intro from './pages/IntroPage/index';
import Input from './pages/InputPage/index';
import NotFound from './pages/NotFound';
import useFindUser from './hooks/useFindUser';

function App() {
  
  const { 
    user, 
    setUser, 
    isLoading } = useFindUser();

  return (
   <Router>
       <UserContext.Provider value={{ user, setUser, isLoading }}>
       <Switch>
          <Route exact path="/" component={Intro}/>  
          <Route path="/login" component={Login}/>
          <PrivateRoute path="/home" component={Input}/>
          <Route component={NotFound}/>
        </Switch>
      </UserContext.Provider>
   </Router>
  );
}

export default App;
