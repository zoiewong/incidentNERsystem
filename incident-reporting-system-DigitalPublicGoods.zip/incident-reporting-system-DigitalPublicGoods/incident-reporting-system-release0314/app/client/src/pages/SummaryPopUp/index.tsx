import React, { useState } from "react";
import Tooltip, { tooltipClasses, TooltipProps } from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';


interface CorrectedOutput {
    entity: string, 
    correctedEntity: string,
    entityType: string, 
    correctedEntityType: string, 
    intention: string, 
    correctedIntention: string, 
    relationship: string
  };

//text colors
const color_dict: { [key: string]: string } = {
    "Drug" : "text-amber-700",
    "Strength_amount" : "text-emerald-400",
    "Dosage" : "text-sky-400",
    "Form_form" : "text-red-600",
    "Form_mode": "text-lime-500",
    "Strength_rate" : "text-blue-700",
    "Strength_concentration" : "text-violet-700",
    "Route" : "text-fuchsia-500",
    "Duration" : "text-gray-500",
    "Timing" : "text-orange-500",
    "Date" : "text-yellow-400",
    "Frequency" : "text-neutral-500"
  }

function CaseInfo(props: any) {
  const [entities] = useState(props.entities);

  function renderIA(i: CorrectedOutput) {
    if (i.correctedIntention === "IA") {
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.correctedEntityType]} text-center text-lg border-2 border-slate-900`}>{i.correctedEntityType}</div>
          <div className={`${color_dict[i.correctedEntityType]} col-span-2 text-center text-lg border-2 border-slate-900`}>{i.correctedEntity}</div>
        </div>
      )
    } else if (i.correctedIntention === "IN"){
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.correctedEntityType]} text-center text-lg border-2 border-slate-900`}>{i.correctedEntityType}</div>
          <div className={`${color_dict[i.correctedEntityType]} text-center text-lg border-2 border-slate-900`}>{i.correctedEntity}</div>
          <div className="border-2 border-slate-900"></div>
        </div>
      )
    } else if (i.correctedIntention === "NA"){
      return(
        <div className="grid grid-cols-3 border-r-2">
          <div className={`${color_dict[i.correctedEntityType]} text-center text-lg border-2 border-slate-900`}>{i.correctedEntityType}</div>
          <div className="border-2 border-slate-900"></div>
          <div className={`${color_dict[i.correctedEntityType]} text-center text-lg border-2 border-slate-900`}>{i.correctedEntity}</div>
        </div>
      )
    } else {
      return (null)
    }
  }
    
  return (
    <div className="flex-initial pb-5">
      <div className="grid grid-cols-3 bg-emerald-400 border-2 border-slate-900">
        <div className="text-center border-r-4 border-slate-900">Entity type</div>
        <div className="text-center">Intended</div>
        <div className="text-center">Actual</div>
      </div>
      {entities.map((item: CorrectedOutput) => {
          return(renderIA(item))
      })}
    </div>
  )
}

const HtmlTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} placement="top" arrow/>
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(14),
    border: '1px solid #dadde9',
  },
}));

function TooltipContent(props: any) {
  const [content] = useState(props.data);

  const fullIntention = (intention : string) => {
    if (intention === "IA") {return ("Intended and Actual")}
    else if (intention === "IN") {return ("Intended and Not-Actual")}
    else if (intention === "NA") {return ("Not-Intended and Actual")}
    else {return ("Not-Intended and Not-Actual")}
  }

  return (
    <div>
      <ul>
        <li>Entity name : <b>{content.correctedEntity}</b></li>
        <li>Entity Type : <b><span className={`${color_dict[content.correctedEntityType]}`}>{content.correctedEntityType}</span></b></li>
        <li>Intention : <b>{fullIntention(content.correctedIntention)} ({content.correctedIntention})</b></li>
      </ul>
    </div>
  )
}

function EntityHover(props: any) {
  const [entityInfo] = useState(props.info);

  return(
    <HtmlTooltip
        title={
          <React.Fragment>
            <Typography color="inherit">Entity Info :</Typography>
            <TooltipContent data={entityInfo}/>
          </React.Fragment>
        }
      >
        <span className={`${color_dict[entityInfo.correctedEntityType]} text-xl underline`}>
          {entityInfo.correctedEntity}
        </span>
    </HtmlTooltip>
  )
}

function SummaryPopUp(props: any) {
    const [data] = useState(props.data);
    const [reportText] = useState(props.report);

    const incidentListToString = (incidents: string[]) => {
        let incident = "";
        incidents.slice(0, incidents.length - 1).map((item : string) => {
          incident += item + ", ";
        })
        incident += incidents[incidents.length - 1];
        return incident;
    }

    const bratString = () => {
        let wordArray = [];
        let start = 0;
        data.entities.map((item : CorrectedOutput) => {
            let position = reportText.indexOf(item.correctedEntity, start);
            if (position > -1) {
                let wordEnd = position + item.correctedEntity.length;
                wordArray.push(<span className="text-xl">{reportText.substring(start, position)}</span>);
                wordArray.push(<EntityHover info={item}/>);
                start = wordEnd;
            }
        })
        wordArray.push(<span className="text-xl">{reportText.substring(start, reportText.length)}</span>);
        return wordArray;
    }

    return(
        <div className="ml-5">
            <h1 className="text-lg text-center">Registration successful!</h1>
            <div>
                <p>Annotation Summary: </p> 
                <p>{bratString()}</p>
            </div>
            <div className="mt-5">Annotation Table: </div>
            <div className="grid grid-cols-3 items-center gap-x-5">
                <div className="col-span-2"><CaseInfo entities={data.entities}/></div>
                <div className="text-center">
                    <p>Incident Type(s) : <b>{incidentListToString(data.correctIncidentTypes)}</b></p>
                </div>
            </div>
        </div>
    );
};

export default SummaryPopUp;
