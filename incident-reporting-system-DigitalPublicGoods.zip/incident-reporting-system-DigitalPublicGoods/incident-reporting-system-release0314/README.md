# Medical incident report web system
This is the instruction and information of incident report demo application that developed at DDAM between 2022/02 ~ 2022/03.

## FOR LOCAL DEVELOPMENT
1. Prepare environment
    - All backend codes are require python version 3.8 (Make sure you have install `python@3.8`)
    - Database is `mysql` with version 8. So make sure you have `mysql` installed on 
    your machine. And create database.
    - Download pytorch model and put in `app/model` directory
        - Model name must be `incident_model.bin`
    - Create python virtual environment and activate it
        - Create: `python3 -m venv env`
        - Activate: `source env/bin/activate`
    - Install backend dependicies
        - `pip3 install -r app/requirements.txt`
        - `python -m spacy download ja_core_news_md`
    - Frontend runs on node with version `v17.5.0`
        - Change directory to `app/client`
        - Install packages by `npm install` (This will create `node_modules` directory)

2. Configure environment variables
    - Backend cofiguration
        - Change global variable `ENVIRONMENT` to `DEV` in file named `app/config/globalConfig.py`
        - Configure database env variables in `app/config/globalConfig.py` file that start with `DEV_DB_*`
        - On `app/main.py` file comment out line 12 which is `from getToken import cognito_auth, get_current_user`. (Because it needs to AWS credentials)
    - Frontend configuration
        - Uncomment line 8 in file `app/client/src/index.js`
3. Start backend server
    - Change directory to `app/`
    - And execute command:
        ```shell
        gunicorn --bind 0.0.0.0:9090 --workers 1 --worker-class uvicorn.workers.UvicornWorker --threads 4 main:app --timeout 600
        ```
4. Start frontend server
    - On another shell change directory `app/client`
    - And execute command:
        ```shell
        npm start
        ```
## FOR PRODUCTION DEPLOYMENT
### For infrastructure building instruction see `infra/README.MD`
This system uses docker image to deploy on AWS ElasticBeanstalk. Works fine on docker version `20.10.10`

1. Configure environment variables and push code to git
    - Backend cofiguration
        - Change global variable `ENVIRONMENT` to `PROD` in file named `app/config/globalConfig.py`
    - Frontend configuration
        - Comment out line 8 in file `app/client/src/index.js`
2. Build frontend static files for production
    - Change directory to `app/client`
    - Build
        ```shell
        npm run build
        ```
3. Login to aws
    - You can use `aws configure`.
4. Login to Elastic container registry
    - ```shell
        aws ecr get-login-password --region ap-northeast-1 | docker login --username AWS --password-stdin 695350421836.dkr.ecr.ap-northeast-1.amazonaws.com
      ```
5. Build your Docker image using the following command.
    - ```shell
        docker build -t incident_report .
      ```
6. After the build completes, tag your image so you can push the image to this repository.
    - ```shell
      docker tag incident_report:latest 695350421836.dkr.ecr.ap-northeast-1.amazonaws.com/incident_report:latest
      ```
7. Run the following command to push this image to your created AWS repository
    - ```shell
      docker push 695350421836.dkr.ecr.ap-northeast-1.amazonaws.com/incident_report:latest
      ```
8. Select EB(ElasticBeanstalk) environment you created.
    - ```shell
      eb init
      ```
9. Deploy EB
    - ```shell
      eb deploy
      ```
