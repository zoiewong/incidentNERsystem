from pydantic import BaseModel
from fastapi import FastAPI, Response, Request, HTTPException
from starlette.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from inference import Predictor
from report_similarity import Adviser
import incident
import models
from database import engine, insertReports, updateReports
from getToken import cognito_auth, get_current_user
import logging
import datetime
from typing import List
from config.globalConfig import ENVIRONMENT, MAIN_LOG_PATH, DEV_ORIGINS, DEV_STATICFILE_PATH, PROD_STATICFILE_PATH, DEV_DATA


def setup_log(name):
    # Logging setup
    logger = logging.getLogger(name)  # > set up a new name for a new logger
    logger.setLevel(logging.DEBUG)  # here is the missing line
    log_format = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log_handler.setFormatter(log_format)
    logger.addHandler(log_handler)
    return logger


def dbConfigure():
    # Create database tables and insert data
    try:
        # create table
        models.Base.metadata.create_all(bind=engine)
        logger.info("Database table creation success")
    except Exception as e:
        logger.error("Database table creation failed: {message}".format(message=e))


logger = setup_log(MAIN_LOG_PATH)
date = datetime.date.today()
year = date.strftime("%Y")
predictor = Predictor()
adviser = Adviser()
dbConfigure()

if ENVIRONMENT == "DEV":
    ALLOW_ORIGINS = [DEV_ORIGINS]
    STATIC_FILES = DEV_STATICFILE_PATH
else:
    ALLOW_ORIGINS = ["*"]
    STATIC_FILES = PROD_STATICFILE_PATH


# SCHEMAS FOR API
class Input(BaseModel):
    text: str
    reportType: str


class LoginInput(BaseModel):
    username: str
    password: str


class Case(BaseModel):
    text: str
    case_type: str


class Entity(BaseModel):
    entity: str
    entityType: str
    intention: str
    relationship: str


class EntityWithCorrection(BaseModel):
    index: str
    outputEntity: Entity
    correctEntity: Entity


class AllEntities(BaseModel):
    entities: List[EntityWithCorrection]
    incidentTypes: List[str]
    correctIncidentTypes: List[str]
    text: str
    reportType: str


# APP CREATION
app = FastAPI(
    title="Incident report API",
    version="0.1.0",
    redoc_url=None,
)

# MIDDLEWARE
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/auth/login")
async def login(d: LoginInput, response: Response):
    try:
        if ENVIRONMENT == "DEV":
            data = DEV_DATA
            token = "qwer"
        else:
            cognito_result = cognito_auth(d.username, d.password)
            data = {"username": d.username, "password": d.password}
            token = cognito_result["AuthenticationResult"]["AccessToken"]
        content = {"status": "success", "token": token, "data": data}
        response = JSONResponse(content=content)
        response.set_cookie(
            key="jwt",
            expires=86400,
            value=token,
            samesite="lax",
            secure=False,
            httponly=False,
            domain="http://localhost",
        )
        logger.info("Login success")
        return response
    except Exception as e:
        logger.error("Login failed: {message}".format(message=e))
        raise HTTPException(status_code=401, detail="UNAUTHORIZED")


# check if user is logged in
@app.get("/api/user")
async def check_user(req: Request):
    try:
        jwt = req.headers["token"]
        logger.info("Token parse success")
    except Exception as e:
        logger.error("{}".format(e))
        jwt = None
    if jwt is None:
        user = None
        logger.error("JWT IS NONE")
    else:
        if ENVIRONMENT == "DEV":
            user = "testUser0308"
        else:
            user = get_current_user(jwt)
    content = {"currentUser": user}
    response = JSONResponse(content=content)
    logger.info("Check user success")
    return response


@app.post("/api/predict", tags=["Predict"])
def predict(d: Input):
    text, out_pos, out_int, out_rel = predictor.inference(d.text)
    logger.info("Prediction success")
    # get entity type, indexes of tokenized entity
    ans = []
    for idx2, ele in enumerate(out_pos):
        mini = []
        if ele.startswith("B"):
            count = idx2
            # clean entity name from token name
            entity_name = ele.replace("B-", "")
            mini.append(entity_name)

            # pick token indexes that contain only one entity
            while count <= len(out_pos) - 2:
                mini.append(count)
                count += 1
                if out_pos[count] == "O" or out_pos[count].startswith("B"):
                    break
        if mini != []:
            ans.append(mini)

    # append dicts to list
    resultList = []
    for a in ans:
        resDict = {}
        if len(a) > 1:
            entity = "".join(text[a[1] : a[-1] + 1])

        # key: entity, entity type, intention, relationship
        resDict["entity"] = entity
        resDict["entityType"] = a[0]
        resDict["intention"] = out_int[a[1]]
        resDict["relationship"] = out_rel[a[1]]
        resultList.append(resDict)

    incident_types = incident.find_incidents(resultList)

    return {"entities": resultList, "incidentTypes": incident_types}


@app.post("/api/correct_annotation", tags=["CorrectAnnotation"])
def correct_annotation(d: AllEntities):
    resultList = []
    corrected_entities = []
    for ent in d.entities:
        ent_dict = {}
        ent_dict["entity"] = ent.outputEntity.entity
        ent_dict["entityType"] = ent.outputEntity.entityType
        ent_dict["intention"] = ent.outputEntity.intention
        ent_dict["relationship"] = ent.outputEntity.relationship
        ent_dict["correctedEntity"] = ent.correctEntity.entity
        ent_dict["correctedEntityType"] = ent.correctEntity.entityType
        ent_dict["correctedIntention"] = ent.correctEntity.intention

        corrected_entities_dict = {}
        corrected_entities_dict["entity"] = ent.correctEntity.entity
        corrected_entities_dict["entityType"] = ent.correctEntity.entityType
        corrected_entities_dict["intention"] = ent.correctEntity.intention
        corrected_entities_dict["relationship"] = ent.outputEntity.relationship

        corrected_entities.append(corrected_entities_dict)
        resultList.append(ent_dict)

    queryDict = {}
    # jwt = req.headers["token"]
    # queryDict["username"] = get_current_user(jwt)
    queryDict["username"] = "testUser0308"
    queryDict["report"] = str(d.text)
    queryDict["predicted_entities"] = str(d.entities)
    queryDict["predicted_incidentTypes"] = str(d.incidentTypes)
    queryDict["reportType"] = str(d.reportType)
    queryDict["reportedYear"] = year

    try:
        insertReports(queryDict)
        logger.info("Database insertion success")
    except Exception as e:
        logger.error("Report insert failed: {message}".format(message=e))

    queryDict = {}
    queryDict["corrected_entities"] = str(corrected_entities)
    queryDict["corrected_incidentTypes"] = str(d.correctIncidentTypes)
    report = str(d.text)
    try:
        updateReports(report, queryDict)
        logger.info("Database update success")
    except Exception as e:
        logger.error("Report update failed: {message}".format(message=e))
        raise HTTPException(status_code=401, detail="DATABASE CONNECTION FAILED")

    return {
        "entities": resultList,
        "incidentTypes": d.incidentTypes,
        "correctIncidentTypes": d.correctIncidentTypes,
    }


@app.post("/api/advise", tags=["Advise"])
def advise(d: Input):
    result = adviser.closest_advice(d.text)
    logger.info("Adviser success")
    return result


@app.post("/api/similar_cases", tags=["SimilarCases"])
def get_similar_cases(d: Case):
    reportType = d.case_type

    cases = adviser.find_similar_cases(d.text, reportType)
    # TODO Change according to preferences. For now, we have only 50 reports so I chose a very low threshold in order to have some results.
    similarity_threshold = 0.0
    most_similar_cases = list(
        filter(lambda x: x["similarity_score"] > similarity_threshold, cases)
    )
    most_similar_cases = [
        {k: v for k, v in d.items() if k != "similarity_score"}
        for d in most_similar_cases
    ]
    # Report type and Error type aren't specified in the source file where the reports came from. So they are filled with a default value for now
    most_similar_cases = [
        dict(
            item,
            **{
                # "type": "Accident" if item["id"].startswith("A") else "Near Miss",
                "type": reportType,
                "error": incident.find_incidents(item["reportEntities"]),
            }
        )
        for item in most_similar_cases
    ]
    # Set number of close cases returned. nb_reports can be replaced with any number.
    nb_reports = 50

    # Since I set all 50 reports used as known cases to Accident type, if case_type is Near Miss, there will be no output.
    logger.info("Search similar case success")
    return most_similar_cases[:nb_reports]


@app.get("/api/doc", include_in_schema=False)
def main():
    return RedirectResponse(url="/docs/")


class SPAStaticFiles(StaticFiles):
    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        if response.status_code == 404:
            response = await super().get_response(".", scope)
        return response


app.mount("/", SPAStaticFiles(directory=STATIC_FILES, html=True), name="index")
