def drug_incidents(data):
    drug_entities = list(filter(lambda x: x["entityType"] == "Drug", data))
    intentions = list(set([i["intention"] for i in drug_entities]))
    if "IN" in intentions:
        if "NA" in intentions:
            return ["Wrong Drug"]
        else:
            return ["Drug Omission"]
    if "NA" in intentions:
        return ["Extra Drug"]

    return []


def other_incidents(data, entity_type):
    entities = list(
        filter(
            lambda x: x["entityType"] == entity_type
            and (x["intention"] == "IN" or x["intention"] == "NA"),
            data,
        )
    )
    if len(entities) > 0:
        return ["Wrong " + entity_type]
    else:
        return []


def find_incidents(data):
    incidents = []
    incidents += drug_incidents(data)
    for i in [
        "Strength_amount",
        "Strength_rate",
        "Strength_concentration",
        "Dosage",
        "Form_form",
        "Form_mode",
        "Route",
        "Date",
        "Duration",
        "Timing",
        "Frequency",
    ]:
        incidents += other_incidents(data, i)

    if len(incidents) == 0:
        return ["Others"]
    else:
        return incidents
